<?php

session_start();

session_destroy();

header(
    "Location: ../html/ktboard.html"
);

exit;
?>
