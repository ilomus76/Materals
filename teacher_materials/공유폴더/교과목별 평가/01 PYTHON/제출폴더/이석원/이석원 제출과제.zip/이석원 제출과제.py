sum_kor=[]
sum_eng=[]
sum_math=[]
file=open('C:/Users/Admin/MBCA/Python/Projects/files/scores.csv', 'r', encoding='UTF-8')

for line in file:
    name, kor, eng, math=line.split(',')
    if kor.strip().isdigit():
        sum_kor.append(int(kor))
    if eng.strip().isdigit():
        sum_eng.append(int(eng))
    if math.strip().isdigit():
        sum_math.append(int(math))
        
print("국어 최고 점수:",max(sum_kor))
print("국어 최저 점수:",min(sum_kor))
print("국어 평균 점수:",sum(sum_kor)/len(sum_kor))
print()

print("영어 최고 점수:",max(sum_eng))
print("영어 최저 점수:",min(sum_eng))
print("영어 평균 점수:",sum(sum_eng)/len(sum_eng))
print()

print("수학 최고 점수:",max(sum_math))
print("수학 최저 점수:",min(sum_math))
print("수학 평균 점수:",sum(sum_math)/len(sum_math))

print("[과목별 통계]")
print(f"국어 - 평균:{sum(sum_kor)/len(sum_kor):.2f}, 최고점: {max(sum_kor)}, 최저점: {min(sum_kor)}")
print(f"영어 - 평균:{sum(sum_eng)/len(sum_eng):.2f}, 최고점: {max(sum_eng)}, 최저점: {min(sum_eng)}")
print(f"수학 - 평균:{sum(sum_math)/len(sum_math):.2f}, 최고점: {max(sum_math)}, 최저점: {min(sum_math)}")

file.seek(0)

for line in file:
    name, kor, eng, math=line.split(',')
    if kor.strip().isdigit():
        kor=int(kor)
    if eng.strip().isdigit():
        eng=int(eng)
    if math.strip().isdigit():
        math=int(math)
        print(f"{name}학생의 총점은 {kor+eng+math}점이고 평균은 {(kor+eng+math)/3:.2f}점 입니다.")
        

file.close()

file=open('students score.csv','w', encoding='UTF-8')
file.write('''
김철수, 253, 84.33333333333333
이영희, 275, 91.66666666666667
박민수, 228, 76.0
최수지, 274, 91.33333333333333
정우성, 277, 92.33333333333333
한가은, 264, 88.0
오상민, 237, 79.0
윤지호, 267, 89.0''')
file.close()